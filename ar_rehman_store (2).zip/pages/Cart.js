import React from "react";
export const Cart = () => (
  <section className="p-6 text-center">
    <h2 className="text-3xl font-bold">Cart Page</h2>
    <p>This is the cart page of AR Rehman Store.</p>
  </section>
);
