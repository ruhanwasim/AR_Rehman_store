import React from "react";
export const Home = () => (
  <section className="p-6 text-center">
    <h2 className="text-3xl font-bold">Home Page</h2>
    <p>This is the home page of AR Rehman Store.</p>
  </section>
);
