import React from "react";
export const Checkout = () => (
  <section className="p-6 text-center">
    <h2 className="text-3xl font-bold">Checkout Page</h2>
    <p>This is the checkout page of AR Rehman Store.</p>
  </section>
);
