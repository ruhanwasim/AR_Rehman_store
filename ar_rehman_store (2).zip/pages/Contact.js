import React from "react";
export const Contact = () => (
  <section className="p-6 text-center">
    <h2 className="text-3xl font-bold">Contact Page</h2>
    <p>This is the contact page of AR Rehman Store.</p>
  </section>
);
