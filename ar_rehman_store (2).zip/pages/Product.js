import React from "react";
export const Product = () => (
  <section className="p-6 text-center">
    <h2 className="text-3xl font-bold">Product Page</h2>
    <p>This is the product page of AR Rehman Store.</p>
  </section>
);
