import React from "react";
export const Navbar = () => (
  <nav className="bg-white shadow p-4 flex justify-between items-center">
    <h1 className="text-2xl font-bold">AR Rehman</h1>
    <div className="space-x-4">
      <a href="/">Home</a>
      <a href="/shop">Shop</a>
      <a href="/about">About</a>
      <a href="/contact">Contact</a>
      <a href="/cart">Cart</a>
    </div>
  </nav>
);

export const Footer = () => (
  <footer className="bg-gray-100 text-center p-4 mt-8">
    <p>&copy; 2025 AR Rehman. All rights reserved.</p>
  </footer>
);
